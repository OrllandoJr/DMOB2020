package com.example.agenda;

import java.util.ArrayList;

public class listaDeContato {

    ArrayList<Contatos> contato = new ArrayList();

    public void CadastrarContato(Contatos contatos){
        contato.add(contatos);
    }
}
