package com.example.agenda;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ArrayList<Contatos> contato = new ArrayList();

        //Contatos cont new Contatos("carlos", "991331792");
        //for (Contatos c : contato){
        //System.out.println(c);


    private Button btnAdiciona, btnEdita;
    private EditText nome, telefone;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnAdiciona = findViewById(R.id.btnAdicionar);
        btnEdita = findViewById(R.id.btnEditar);

        nome = findViewById(R.id.editTextNome);
        telefone = findViewById(R.id.editTextTelefone);

    }
        public void Lista(View view){
            String A = nome.getText().toString().trim();
            String B = telefone.getText().toString().trim();


        }

}

