package com.example.agenda;

public class Contatos {
            private String nome;
            private String celular;

            public Contatos(){

            }
            public Contatos(String nome, String celular){
                this.nome=nome;
                this.celular=celular;
            }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }
}
