package com.example.mobile;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class calculadora extends AppCompatActivity {

    private Button btnSoma, btnDiv, btnMulti, btnSub, btnLimpa, btnPorc;
    private EditText n1, n2;
    private TextView resultado;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculadora);

        //Criamos variáveis para cada um dos widgets.
        btnSoma = findViewById(R.id.btnCalc);
        btnDiv = findViewById(R.id.btnDividir);
        btnMulti = findViewById(R.id.btnMultiplicar);
        btnSub = findViewById(R.id.btnSubtrair);
        btnPorc = findViewById(R.id.btnPorcentagem);
        btnLimpa = findViewById(R.id.btnLimpar);

        n1 = findViewById(R.id.editTextN1);
        n2 = findViewById(R.id.editTextN2);
        resultado = findViewById(R.id.textViewResultado);
    }

    //Criamos os métodos para cada um dos botões para ser acionado ao ser clicado.
    public void Somar(View view){

        //Pegamos os números inseridos pelo o usuário, estão em formato caracter.
        String A = n1.getText().toString().trim();
        String B = n2.getText().toString().trim();

        //Transformamos os caracters em números para executar as operações.
        Double C = Double.parseDouble(A);
        Double D = Double.parseDouble(B);

        //Realização da operação.
        Double E = C + D;

        //Inserimos o resultado a caixa de em formato caracter.
        resultado.setText(E.toString());
    }
    public void Subtrair(View view) {

        //Pegamos os números inseridos pelo o usuário, estão em formato caracter.
        String A = n1.getText().toString().trim();
        String B = n2.getText().toString().trim();

        //Transformamos os caracters em números para executar as operações.
        Double C = Double.parseDouble(A);
        Double D = Double.parseDouble(B);

        //Realização da operação.
        Double E = C - D;

        //Inserimos o resultado a caixa de em formato caracter.
        resultado.setText(E.toString());
    }
    public void Multiplicar(View view) {

        //Pegamos os números inseridos pelo o usuário, estão em formato caracter.
        String A = n1.getText().toString().trim();
        String B = n2.getText().toString().trim();

        //Transformamos os caracters em números para executar as operações.
        Double C = Double.parseDouble(A);
        Double D = Double.parseDouble(B);

        //Realização da operação.
        Double E = C * D;

        //Inserimos o resultado a caixa de em formato caracter.
        resultado.setText(E.toString());
    }
    public void Dividir(View view) {

        //Pegamos os números inseridos pelo o usuário, estão em formato caracter.
        String A = n1.getText().toString().trim();
        String B = n2.getText().toString().trim();

        //Transformamos os caracters em números para executar as operações.
        Double C = Double.parseDouble(A);
        Double D = Double.parseDouble(B);

        //Realização da operação.
        Double E = C / D;

        //Inserimos o resultado a caixa de em formato caracter.
        resultado.setText(E.toString());
    }
    public void Porcentagem(View view) {

        //Pegamos os números inseridos pelo o usuário, estão em formato caracter.
        String A = n1.getText().toString().trim();
        String B = n2.getText().toString().trim();

        //Transformamos os caracters em números para executar as operações.
        Double C = Double.parseDouble(A);
        Double D = Double.parseDouble(B);

        //Realização da operação.
        Double E = C * D/100;

        //Inserimos o resultado a caixa de em formato caracter.
        resultado.setText(E.toString());

    }
    public void Limpar(View view) {

        //Limpa os campos.
        n1.setText("");
        n2.setText("");
        resultado.setText("");
    }
}